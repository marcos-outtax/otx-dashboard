// content.js v25.6 - correcoes finais
(function(){
  if(window.__outtaxV256)return;
  window.__outtaxV256=true;

  let userName='Você';
  let personNameBuffer='', transcriptTextBuffer='', timestampBuffer='';
  let captureActive=false, transcriptObserver=null;
  let saidaIv=null, flushIv=null;
  let hasMeetingStarted=false, ultimoTextoTime=0;
  let jaEncerrando=false; // evita duplo disparo do MEET_ENDED

  function horaLocal(){
    return new Date().toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit',timeZone:Intl.DateTimeFormat().resolvedOptions().timeZone});
  }
  function dataHoraLocal(){
    return new Date().toLocaleString('pt-BR',{timeZone:Intl.DateTimeFormat().resolvedOptions().timeZone});
  }

  function waitForElement(selector,text,timeout){
    return new Promise((resolve,reject)=>{
      const ms=timeout||300000;
      const start=Date.now();
      function check(){
        if(timeout&&Date.now()-start>ms){reject(new Error('timeout'));return;}
        if(text){
          const el=Array.from(document.querySelectorAll(selector)).find(e=>e.textContent===text);
          if(el){resolve(el);return;}
        } else {
          const el=document.querySelector(selector);
          if(el){resolve(el);return;}
        }
        requestAnimationFrame(check);
      }
      check();
    });
  }

  // Captura nome real via .awLEm (identico ao StackJus)
  waitForElement('.awLEm').then(()=>{
    const iv=setInterval(()=>{
      if(!hasMeetingStarted){
        const nome=document.querySelector('.awLEm')?.textContent?.trim();
        if(nome){userName=nome;chrome.runtime.sendMessage({type:'NOME_USUARIO_MEET',nome}).catch(()=>{});clearInterval(iv);}
      } else clearInterval(iv);
    },100);
  }).catch(()=>{});

  function pushBufferToTranscript(){
    if(!personNameBuffer||!transcriptTextBuffer) return;
    const nomeReal=(personNameBuffer==='Você'||personNameBuffer==='You')?userName:personNameBuffer;
    const seg=nomeReal+': '+transcriptTextBuffer;
    console.log('[Outtax] ENVIANDO:',seg.substring(0,80));
    const h=horaLocal();
    const send=()=>chrome.runtime.sendMessage({type:'SR_RESULT',text:seg,nome:nomeReal,final:true,horaLocal:h}).catch(()=>setTimeout(send,1500));
    send();
  }

  function transcriptMutationCallback(){
    try{
      const people=document.querySelector('div[role="region"][tabindex="0"]')?.childNodes;
      if(!people) return;

      if(people.length>1){
        let person=people[people.length-2];
        if(person&&person.childNodes.length<2) person=people[people.length-3];
        if(!person||person.childNodes.length<2) return;

        const currentPersonName=person.childNodes[0].textContent;
        const currentTranscriptText=person.childNodes[1].textContent;

        if(currentPersonName&&currentTranscriptText){
          ultimoTextoTime=Date.now(); // sempre atualiza ao receber texto
          if(transcriptTextBuffer===''){
            personNameBuffer=currentPersonName;
            timestampBuffer=new Date().toISOString();
            transcriptTextBuffer=currentTranscriptText;
          } else if(personNameBuffer!==currentPersonName){
            pushBufferToTranscript();
            personNameBuffer=currentPersonName;
            timestampBuffer=new Date().toISOString();
            transcriptTextBuffer=currentTranscriptText;
          } else {
            if((currentTranscriptText.length-transcriptTextBuffer.length)<-250){
              // Meet resetou o texto longo - envia bloco anterior
              pushBufferToTranscript();
              timestampBuffer=new Date().toISOString();
            } else if(currentTranscriptText.length>=400){
              // Buffer grande - envia para nao perder em reunioes longas sem pausa
              pushBufferToTranscript();
              timestampBuffer=new Date().toISOString();
            }
            transcriptTextBuffer=currentTranscriptText;
          }
        }
      } else {
        if(personNameBuffer&&transcriptTextBuffer){
          pushBufferToTranscript();
        }
        personNameBuffer='';transcriptTextBuffer='';
      }
    }catch(e){console.error('[Outtax]',e.message);}
  }

  function ativarLegendas(){
    const icones=Array.from(document.querySelectorAll('.google-symbols'));
    if(icones.find(e=>e.textContent==='closed_caption')) return true;
    const off=icones.find(e=>e.textContent==='closed_caption_off');
    if(off){const btn=off.closest('button');if(btn){btn.click();return true;}}
    for(const btn of document.querySelectorAll('button')){
      const label=(btn.getAttribute('aria-label')||'').toLowerCase();
      if(label.includes('legenda')||label.includes('caption')){
        if(btn.getAttribute('aria-pressed')!=='true') btn.click();
        return true;
      }
    }
    return false;
  }

  function ocultarContainer(container){
    // visibility:hidden oculta mas mantem o DOM renderizado (texto disponivel)
    container.style.cssText+='opacity:0.01 !important;pointer-events:none !important;';
  }

  function iniciarObserver(container){
    ocultarContainer(container);
    transcriptObserver=new MutationObserver(transcriptMutationCallback);
    transcriptObserver.observe(container,{childList:true,attributes:true,subtree:true,characterData:true});
    // Flush: se ficou 6s sem texto novo, envia o buffer
    flushIv=setInterval(()=>{
      if(!captureActive||!transcriptTextBuffer) return;
      if(ultimoTextoTime>0&&Date.now()-ultimoTextoTime>6000){
        console.log('[Outtax] flush automatico');
        pushBufferToTranscript();
        personNameBuffer='';transcriptTextBuffer='';ultimoTextoTime=0;
      }
    },2000);
    console.log('[Outtax] observer ativo');
  }

  function iniciarCaptura(){
    if(captureActive) return;
    captureActive=true;hasMeetingStarted=true;
    personNameBuffer='';transcriptTextBuffer='';ultimoTextoTime=0;
    console.log('[Outtax] captura iniciada, usuario:',userName);
    ativarLegendas();
    const c=document.querySelector('div[role="region"][tabindex="0"]');
    if(c){iniciarObserver(c);return;}
    waitForElement('div[role="region"][tabindex="0"]',null,15000)
      .then(c=>iniciarObserver(c))
      .catch(()=>{
        ativarLegendas();
        waitForElement('div[role="region"][tabindex="0"]',null,15000)
          .then(c=>iniciarObserver(c))
          .catch(e=>console.error('[Outtax]',e.message));
      });
  }

  function pararCaptura(){
    if(personNameBuffer&&transcriptTextBuffer) pushBufferToTranscript();
    personNameBuffer='';transcriptTextBuffer='';
    captureActive=false;
    if(flushIv){clearInterval(flushIv);flushIv=null;}
    if(transcriptObserver){transcriptObserver.disconnect();transcriptObserver=null;}
    const c=document.querySelector('div[role="region"][tabindex="0"]');
    if(c){c.style.cssText=c.style.cssText.replace(/opacity[^;]*;?/g,'').replace(/pointer-events[^;]*;?/g,'');}
    console.log('[Outtax] captura parada');
  }

  function encerrarReuniao(){
    if(!captureActive||jaEncerrando) return;
    jaEncerrando=true;
    console.log('[Outtax] encerrando');
    // Executa o callback uma ultima vez para pegar texto mais recente do DOM
    transcriptMutationCallback();
    // Pequena espera para o Meet atualizar o DOM com a ultima palavra
    setTimeout(()=>{
      transcriptMutationCallback(); // tenta de novo
      pararCaptura();
      setTimeout(()=>chrome.runtime.sendMessage({type:'MEET_ENDED'}).catch(()=>{}),1500);
    },500);
  }

  function monitorarSaida(){
    if(saidaIv) return;
    // Click listener no botao vermelho - igual ao StackJus
    try{
      const callEndIcon=Array.from(document.querySelectorAll('.google-symbols')).find(e=>e.textContent==='call_end');
      if(callEndIcon){
        const btn=callEndIcon.closest('button')||callEndIcon.parentElement?.parentElement;
        if(btn) btn.addEventListener('click',()=>encerrarReuniao(),{once:true});
      }
    }catch(_){}

    // Polling fallback
    saidaIv=setInterval(()=>{
      const emReuniao=/meet\.google\.com\/[a-z]+-[a-z]+-[a-z]+/.test(location.href);
      const saiuTela=document.body.innerText.includes('Você saiu da reunião')||
                     document.body.innerText.includes('Voltando à tela inicial');
      if((!emReuniao||saiuTela)&&captureActive){
        clearInterval(saidaIv);saidaIv=null;
        encerrarReuniao();
      }
    },1500);
  }

  function getTitulo(){
    const m=location.href.match(/meet\.google\.com\/([a-z]+-[a-z]+-[a-z]+)/);
    return m?m[1]:document.title.replace(' - Google Meet','').trim()||'Reuniao';
  }

  chrome.runtime.onMessage.addListener((msg,_s,resp)=>{
    if(msg.type==='GET_TITLE'){resp({title:getTitulo(),dataHora:dataHoraLocal()});return true;}
    if(msg.type==='SR_START'){
      if(msg.nomeUsuario?.trim()) userName=msg.nomeUsuario.trim();
      iniciarCaptura();monitorarSaida();resp({ok:true});return true;
    }
    if(msg.type==='NOME_USUARIO_BG'){
      if(msg.nome?.trim()) userName=msg.nome.trim();
      console.log('[Outtax] nome BG:',userName);return true;
    }
    if(msg.type==='SR_STOP'){
      pararCaptura();
      if(saidaIv){clearInterval(saidaIv);saidaIv=null;}
      resp({ok:true});return true;
    }
    return true;
  });

  // INICIO AUTOMATICO
  waitForElement('.google-symbols','call_end').then(()=>{
    console.log('[Outtax] reuniao detectada');
    chrome.runtime.sendMessage({type:'AUTO_START',title:getTitulo(),dataHora:dataHoraLocal()}).catch(()=>{});
    iniciarCaptura();
    monitorarSaida();
  }).catch(()=>{});

  chrome.runtime.sendMessage({type:'MEET_TITLE',title:getTitulo(),dataHora:dataHoraLocal()}).catch(()=>{});
  console.log('[Outtax] v25.6 carregado');
})();
