// background.js v23 - tokens persistidos, inicio automatico
const DASHBOARD='https://otx-dashboard.vercel.app';
let transcript=[],capturing=false,meetTabId=null;
let participantes=new Set();
let meetTitle='Reuniao',startTime=null,lastText='';
let horaClienteStr='';

function badge(text,color){
  chrome.action.setBadgeText({text:text||''});
  if(color)chrome.action.setBadgeBackgroundColor({color});
}

// Persiste transcript a cada segmento
function persistirTranscript(){
  chrome.storage.session.set({transcript:JSON.stringify(transcript),meetTitle,horaClienteStr}).catch(()=>{});
  chrome.storage.local.set({transcriptBackup:JSON.stringify(transcript),meetTitleBackup:meetTitle}).catch(()=>{});
}

async function iniciarCaptura(tabId,title,dataHora){
  if(capturing&&meetTabId===tabId) return; // ja gravando esta reuniao
  capturing=true;transcript=[];meetTabId=tabId;
  meetTitle=title||'Reuniao';startTime=new Date();lastText='';
  horaClienteStr=dataHora||'';
  badge('REC','#E24B4A');
  await chrome.storage.session.set({capturing:true,meetTabId:tabId,meetTitle:title});
  console.log('[BG] captura iniciada tab',tabId,title);
}

async function pararCaptura(){
  capturing=false;
  badge('',null);
  await chrome.storage.session.set({capturing:false,meetTabId:null});
  if(meetTabId){
    try{chrome.tabs.sendMessage(meetTabId,{type:'SR_STOP'},()=>{});}catch(_){}
  }
}

async function salvar(){
  // Recupera transcript do storage se memoria perdida
  if(!transcript.length){
    const sess=await chrome.storage.session.get(['transcript','meetTitle','horaClienteStr']);
    if(sess.transcript){
      try{
        transcript=JSON.parse(sess.transcript);
        if(sess.meetTitle) meetTitle=sess.meetTitle;
        if(sess.horaClienteStr) horaClienteStr=sess.horaClienteStr;
        console.log('[BG] transcript recuperado do session:',transcript.length);
      }catch(_){}
    }
    if(!transcript.length){
      const local=await chrome.storage.local.get(['transcriptBackup','meetTitleBackup']);
      if(local.transcriptBackup){
        try{
          transcript=JSON.parse(local.transcriptBackup);
          if(local.meetTitleBackup) meetTitle=local.meetTitleBackup;
          console.log('[BG] transcript recuperado do backup:',transcript.length);
        }catch(_){}
      }
    }
  }

  if(!transcript.length){
    console.log('[BG] nada para salvar');
    capturing=false;badge('',null);return;
  }

  // Busca tokens — primeiro do storage local (persistido), depois do Dashboard se aberto
  await buscarTokensDashboard();
  const cfg=await chrome.storage.local.get(['sessionToken','googleToken','googleRefresh']);

  if(!cfg.sessionToken){
    badge('!','#E24B4A');
    console.error('[BG] sem sessionToken - usuario precisa abrir o Dashboard');
    return;
  }

  const titulo=meetTitle+' — '+new Date().toLocaleDateString('pt-BR');
  const conteudo=transcript.map(e=>'['+e.time+'] '+e.text).join('\n');
  const dataHora=horaClienteStr||new Date().toLocaleString('pt-BR',{timeZone:'America/Sao_Paulo'});
  console.log('[BG] salvando',transcript.length,'segmentos...');

  try{
    // Substitui 'Você' pelo nome real do usuario logado
  const cfg2=await chrome.storage.local.get(['nomeUsuario','googleName']);
  const nomeReal=cfg2.googleName||cfg2.nomeUsuario||'Você';
  const listaParticipantes=[...participantes].map(p=>p==='Você'||p==='You'?nomeReal:p);

  const r=await fetch(DASHBOARD+'/api/transcricoes',{
      method:'POST',
      headers:{
        'Content-Type':'application/json',
        'X-Session-Token':cfg.sessionToken||'',
        'X-Google-Token':cfg.googleToken||'',
        'X-Google-Refresh-Token':cfg.googleRefresh||''
      },
      body:JSON.stringify({titulo,participantes:listaParticipantes.join(', '),conteudo,dataHoraCliente:dataHora})
    });
    const data=await r.json();
    console.log('[BG] API:',r.status,data.erro||'ok');
    if(r.ok&&!data.erro){
      // Salva novo token se renovado
      if(data.newAccessToken){
        const c=await chrome.storage.local.get(['sessionToken','googleRefresh','nomeUsuario']);
        await chrome.storage.local.set({...c,googleToken:data.newAccessToken});
      }
      chrome.notifications.create('outtax_saved',{
        type:'basic',
        iconUrl:chrome.runtime.getURL('icons/icon48.png'),
        title:'Outtax Meet',
        message:'Transcricao salva! '+transcript.length+' segmentos.'
      });
      transcript=[];meetTabId=null;badge('',null);
      // Limpa backup
      chrome.storage.session.set({transcript:'[]'}).catch(()=>{});
      chrome.storage.local.set({transcriptBackup:'[]'}).catch(()=>{});
    }else{
      badge('!','#FF8E2A');
      console.error('[BG] erro API:',data.erro);
    }
  }catch(e){
    console.error('[BG] fetch:',e.message);
    badge('!','#E24B4A');
  }
}

// Busca tokens do Dashboard se estiver aberto — salva permanentemente
async function buscarTokensDashboard(){
  try{
    const tabs=await chrome.tabs.query({url:DASHBOARD+'/*'});
    if(!tabs.length) return;
    const res=await chrome.scripting.executeScript({
      target:{tabId:tabs[0].id},
      func:()=>{
        try{
          const c=JSON.parse(localStorage.getItem('otx_cfg')||'{}');
          if(!c.sessionToken) return null;
          return{
            sessionToken:c.sessionToken||'',
            googleToken:c.googleToken||'',
            googleRefresh:c.googleRefreshToken||'',
            nomeUsuario:c.nomeUsuario||''
          };
        }catch(_){return null;}
      }
    });
    const t=res?.[0]?.result;
    if(t?.sessionToken){
      // Salva permanentemente no storage local (inclui googleName se disponivel)
      await chrome.storage.local.set(t);
      console.log('[BG] tokens salvos permanentemente para:',t.googleName||t.nomeUsuario);
    }
  }catch(e){console.error('[BG] buscarTokens:',e.message);}
}

// Detecta saida do Meet
chrome.tabs.onRemoved.addListener(async(tabId)=>{
  if(tabId===meetTabId){
    console.log('[BG] aba fechada - salvando');
    await pararCaptura();await salvar();
  }
});

chrome.tabs.onUpdated.addListener(async(tabId,info)=>{
  if(tabId!==meetTabId||!capturing) return;
  if(info.url&&!info.url.includes('meet.google.com/')){
    console.log('[BG] URL mudou - salvando');
    await pararCaptura();await salvar();
  }
});

// Polling backup
setInterval(async()=>{
  if(!capturing||!meetTabId) return;
  try{
    const tab=await chrome.tabs.get(meetTabId);
    if(!tab||!tab.url?.includes('meet.google.com/')){
      await pararCaptura();await salvar();
    }
  }catch(_){
    if(capturing){await pararCaptura();await salvar();}
  }
},5000);

// Recupera estado ao reiniciar service worker
chrome.storage.session.get(['capturing','meetTabId','meetTitle','transcript','horaClienteStr']).then(sess=>{
  if(sess.capturing&&sess.meetTabId){
    capturing=true;meetTabId=sess.meetTabId;meetTitle=sess.meetTitle||'Reuniao';
    horaClienteStr=sess.horaClienteStr||'';
    if(sess.transcript){try{transcript=JSON.parse(sess.transcript);}catch(_){}}
    badge(transcript.length?String(transcript.length):'REC','#E24B4A');
    console.log('[BG] estado recuperado:',transcript.length,'segmentos');
  }
}).catch(()=>{});

chrome.runtime.onMessage.addListener((msg,sender,sendResponse)=>{

  // Tokens do Dashboard — salva permanentemente
  if(msg.type==='DASHBOARD_TOKENS'){
    const t=msg.tokens;
    if(t?.sessionToken){
      chrome.storage.local.set({
        sessionToken:t.sessionToken,
        googleToken:t.googleToken||'',
        googleRefresh:t.googleRefresh||'',
        nomeUsuario:t.nomeUsuario||'',
        googleName:t.googleName||''
      });
      console.log('[BG] tokens recebidos do dashboard:',t.nomeUsuario);
    }
    return;
  }

  // Inicio automatico detectado pelo content.js
  if(msg.type==='AUTO_START'){
    const tabId=sender.tab?.id;
    if(tabId){
      iniciarCaptura(tabId,msg.title,msg.dataHora);
      buscarTokensDashboard();
      // Envia nome real para o content.js
      chrome.storage.local.get(['googleName','nomeUsuario']).then(cfg=>{
        const nome=cfg.googleName||cfg.nomeUsuario||'';
        if(nome) chrome.tabs.sendMessage(tabId,{type:'NOME_USUARIO_BG',nome},()=>{});
      });
    }
    return;
  }

  if(msg.type==='MEET_ENDED'){
    console.log('[BG] MEET_ENDED - salvando (capturing='+capturing+')');
    // Salva sempre - mesmo se service worker reiniciou e capturing=false
    pararCaptura().then(()=>salvar());
    return;
  }

  if(msg.type==='SR_RESULT'){
    if(!msg.text) return;
    const txt=msg.text.trim();
    if(txt.length<5) return;
    const hora=msg.horaLocal||new Date().toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit',timeZone:'America/Sao_Paulo'});
    const last=transcript[transcript.length-1];
    if(last&&last.text===txt) return;
    // Extrai corpo sem nome do participante
    const corpo=s=>s.includes(': ')?s.split(': ').slice(1).join(': '):s;
    const lastCorpo=corpo(last?.text||'');
    const txtCorpo=corpo(txt);
    // So substitui se o novo texto CONTEM o anterior no inicio (frase crescendo)
    // Usa os primeiros 30 chars como âncora para evitar falsos positivos
    const ancora=lastCorpo.substring(0,30);
    const eMesmoBlocoCrescendo=lastCorpo.length>20&&txtCorpo.startsWith(lastCorpo.substring(0,lastCorpo.length-5));
    if(last&&ancora.length>10&&txtCorpo.includes(ancora)&&txt.length>last.text.length){
      transcript[transcript.length-1]={time:hora,text:txt};
    } else {
      transcript.push({time:hora,text:txt});
    }
    // Registra participante
    if(msg.nome&&msg.nome!='') participantes.add(msg.nome);
    lastText=txt;
    persistirTranscript();
    badge(String(transcript.length),'#152c6b');
    console.log('[BG] #'+transcript.length+':',txt.substring(0,50));
    return;
  }

  if(msg.type==='PING'){sendResponse({ok:true});return true;}
  if(msg.type==='NOME_USUARIO_MEET'){
    chrome.storage.local.set({googleName:msg.nome}).catch(()=>{});
    console.log('[BG] nome usuario Meet:',msg.nome);
    return;
  }
  if(msg.type==='PING'){sendResponse({ok:true});return true;}
  if(msg.type==='NOME_USUARIO_MEET'){
    chrome.storage.local.set({googleName:msg.nome}).catch(()=>{});
    console.log('[BG] nome usuario Meet:',msg.nome);
    return;
  }
  if(msg.type==='MEET_TITLE'){
    meetTitle=msg.title||meetTitle;
    if(msg.dataHora) horaClienteStr=msg.dataHora;
    return;
  }

  // Inicio manual via popup
  if(msg.type==='START'){
    const tabId=msg.tabId;
    iniciarCaptura(tabId,msg.title,msg.dataHora).then(async()=>{
      // Injeta content.js se necessario
      try{
        await chrome.scripting.executeScript({target:{tabId},files:['src/content.js']});
        // Envia nome do usuario para o content.js usar em vez de 'Você'
    const cfgNome=await chrome.storage.local.get(['googleName','nomeUsuario']);
    const nomeParaEnviar=cfgNome.googleName||cfgNome.nomeUsuario||'';
    setTimeout(()=>chrome.tabs.sendMessage(tabId,{type:'SR_START',nomeUsuario:nomeParaEnviar},()=>{}),500);
      }catch(e){console.error('[BG] inject:',e.message);}
      sendResponse({ok:true});
    });
    return true;
  }

  if(msg.type==='STOP_SAVE'){
    pararCaptura().then(()=>salvar()).then(()=>sendResponse({ok:true}));
    return true;
  }
  if(msg.type==='STOP_DISCARD'){
    pararCaptura().then(()=>{
      transcript=[];meetTabId=null;
      chrome.storage.session.set({transcript:'[]'}).catch(()=>{});
      chrome.storage.local.set({transcriptBackup:'[]'}).catch(()=>{});
      sendResponse({ok:true});
    });
    return true;
  }
  if(msg.type==='GET_STATUS'){
    sendResponse({
      capturing,count:transcript.length,title:meetTitle,
      start:startTime?startTime.toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'}):''
    });
    return true;
  }
});
