(function(){
  // Verifica se extensao esta disponivel
  if(typeof chrome==='undefined'||!chrome.runtime) return;

  function extrairTokens(){
    try{
      const raw=localStorage.getItem('otx_cfg');
      if(!raw) return null;
      const c=JSON.parse(raw);
      if(!c.sessionToken) return null;
      return{
        sessionToken:  c.sessionToken||'',
        googleToken:   c.googleToken||'',
        googleRefresh: c.googleRefreshToken||'',
        nomeUsuario:   c.nomeUsuario||'',
        googleName:    c.googleName||''
      };
    }catch(_){return null;}
  }

  function sincronizar(){
    try{
      const t=extrairTokens();
      if(t?.sessionToken){
        chrome.runtime.sendMessage({type:'DASHBOARD_TOKENS',tokens:t}).catch(()=>{});
      }
    }catch(_){}
  }

  // Aguarda o runtime estar pronto antes de sincronizar
  function iniciar(){
    try{
      sincronizar();
      setInterval(sincronizar,15000);
      window.addEventListener('focus',sincronizar);
      document.addEventListener('visibilitychange',()=>{if(!document.hidden)sincronizar();});
      window.addEventListener('storage',sincronizar);

      chrome.runtime.onMessage.addListener((msg,_s,resp)=>{
        if(msg.type==='GET_DASHBOARD_TOKENS'){resp(extrairTokens());}
        if(msg.type==='PING'){resp({ok:true});}
        return true;
      });
    }catch(_){}
  }

  // Pequeno delay para garantir que o service worker esta pronto
  if(document.readyState==='complete'){
    setTimeout(iniciar,300);
  } else {
    window.addEventListener('load',()=>setTimeout(iniciar,300));
  }
})();
