// popup.js v7
const DASHBOARD = 'https://otx-dashboard.vercel.app';

let tab = null;

function show(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

function bg(type, data) {
  return new Promise(res => {
    chrome.runtime.sendMessage({ type, ...(data || {}) }, r => {
      if (chrome.runtime.lastError) res(null);
      else res(r);
    });
  });
}

// ── Pega tokens — primeiro do storage, depois do dashboard aberto ──
async function obterTokens() {
  // 1. Tenta do storage local
  const stored = await chrome.storage.local.get(['sessionToken', 'googleToken', 'nomeUsuario']);
  if (stored.sessionToken) return stored;

  // 2. Tenta injetar no dashboard se estiver aberto
  try {
    const tabs = await chrome.tabs.query({ url: DASHBOARD + '/*' });
    if (tabs.length > 0) {
      const results = await chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        func: () => {
          try {
            const raw = localStorage.getItem('otx_cfg');
            if (!raw) return null;
            const c = JSON.parse(raw);
            return {
              sessionToken:  c.sessionToken       || '',
              googleToken:   c.googleToken         || '',
              googleRefresh: c.googleRefreshToken  || '',
              nomeUsuario:   c.nomeUsuario          || '',
            };
          } catch (_) { return null; }
        },
      });
      const tokens = results?.[0]?.result;
      if (tokens?.sessionToken) {
        await chrome.storage.local.set(tokens);
        return tokens;
      }
    }
  } catch (_) {}

  return null;
}

// ── Init ───────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
  tab = t;

  const isMeet = tab?.url?.includes('meet.google.com/');

  // Tenta obter tokens automaticamente
  const tokens = await obterTokens();

  if (tokens?.nomeUsuario) {
    document.getElementById('ftr-user').textContent = tokens.nomeUsuario;
  }
  // Debug: mostra status do google token no footer
  const gStatus = tokens?.googleToken ? '✓G' : '!G';
  document.getElementById('ftr-user').textContent = (tokens?.nomeUsuario||'') + ' ' + gStatus;

  // Logout
  document.getElementById('ftr-logout').addEventListener('click', async () => {
    await chrome.storage.local.clear();
    location.reload();
  });

  if (!tokens?.sessionToken) {
    // Nao tem tokens — pede para abrir o dashboard
    show('sc-no-login');
    document.getElementById('btn-abrir-dashboard').addEventListener('click', () => {
      chrome.tabs.create({ url: DASHBOARD });
      window.close();
    });
    return;
  }

  if (!isMeet) {
    show('sc-nomeet');
    return;
  }

  // Tem tokens e esta no Meet
  const status = await bg('GET_STATUS');
  if (status?.capturing) {
    mostrarGravando(status);
  } else {
    await mostrarPronto();
  }
  bindBotoes();
});

// ── Tela Pronto ────────────────────────────────────────
async function mostrarPronto() {
  show('sc-ready');
  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['src/content.js'] });
  } catch (_) {}
  const r = await new Promise(res => {
    chrome.tabs.sendMessage(tab.id, { type: 'GET_TITLE' }, r => {
      if (chrome.runtime.lastError) res(null);
      else res(r);
    });
  });
  const titulo = r?.title || tab.title?.replace(' - Google Meet', '').trim() || 'Reuniao';
  document.getElementById('ready-title').textContent = titulo;
}

// ── Tela Gravando ──────────────────────────────────────
function mostrarGravando(status) {
  show('sc-rec');
  document.getElementById('rec-title').textContent = status?.title || 'Reuniao';
  document.getElementById('rec-meta').textContent  = 'Iniciado as ' + (status?.start || '--:--');
  atualizarContagem(status?.count || 0);
  const poll = setInterval(async () => {
    const s = await bg('GET_STATUS');
    if (!s?.capturing) { clearInterval(poll); return; }
    atualizarContagem(s.count || 0);
    document.getElementById('rec-txt').textContent = (s.count || 0) + ' segmentos capturados';
  }, 4000);
}

function atualizarContagem(n) {
  const el = document.getElementById('hdr-cnt');
  el.textContent = n;
  el.classList.toggle('on', n > 0);
}

// ── Botoes ─────────────────────────────────────────────
function bindBotoes() {
  document.getElementById('btn-start').addEventListener('click', async () => {
    const titulo = document.getElementById('ready-title').textContent;
    const r = await bg('START', { tabId: tab.id, title: titulo });
    if (r?.ok) {
      const s = await bg('GET_STATUS');
      mostrarGravando(s || {});
    }
  });
  document.getElementById('btn-stop').addEventListener('click', async () => {
    await bg('STOP_SAVE');
    await mostrarPronto();
    bindBotoes();
  });
  document.getElementById('btn-discard').addEventListener('click', async () => {
    if (confirm('Descartar a transcricao atual?')) {
      await bg('STOP_DISCARD');
      await mostrarPronto();
      bindBotoes();
    }
  });
}
